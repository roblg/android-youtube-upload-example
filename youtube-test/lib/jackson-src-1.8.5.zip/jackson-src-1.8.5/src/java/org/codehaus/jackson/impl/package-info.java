/**
 * Parser and generator implementation classes that Jackson
 * defines and uses.
 * Application code should not (need to) use contents of this package.
 */
package org.codehaus.jackson.impl;
