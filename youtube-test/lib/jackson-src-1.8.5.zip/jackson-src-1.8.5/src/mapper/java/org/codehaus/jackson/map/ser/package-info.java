/**
 * Contains implementation classes of serialization part of 
 * data binding.
 */
package org.codehaus.jackson.map.ser;
